package AllLinkPk;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class LinkModule 
{
	WebDriver wb;
	String working;
	
	public static void HomePage(WebDriver wb,String working) throws InterruptedException
	  {    
		  WebElement home = wb.findElement(By.linkText("Home"));
		  home.click();
		  		  
		if(wb.getCurrentUrl().equalsIgnoreCase("http://demo.guru99.com/test/newtours/index.php"))
		  {   
			  System.out.println("Test Passed For Home Link");
			  
		  }
		else if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours")|| working==("This section of our web site is currently under construction."))
		{
			  System.out.println("Test Passed For Home Link");
			  WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
		}
		  else
		  {
			  System.out.println("Test Failed For Home Link");
		  }
		
		  wb.manage().timeouts().pageLoadTimeout(5000, TimeUnit.SECONDS);
		  WebElement destination = wb.findElement(By.partialLinkText("your destinati"));
		  destination.click();
		  
		  if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours") || working==("This section of our web site is currently under construction."))
		 {   
			System.out.println("Test Passed For Destinations Link on Home Page");
			 WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
			  
		  }
		  else
		  {
			  System.out.println("Test Failed For Destinations Link on Home Page");
		  }
		  
		  Thread.sleep(5000);
		  WebElement vacations = wb.findElement(By.partialLinkText("featured"));
		  vacations.click();
		  
		  if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours") || working==("This section of our web site is currently under construction."))
		  {   
			System.out.println("Test Passed For vacations Link on Home Page");
			WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
			  
		  }
		  else
		  {
			  System.out.println("Test Failed For vacations Link on Home Page");
		  }
		  
		  
		  Thread.sleep(5000);
		  WebElement register = wb.findElement(By.linkText("Register here"));
		  register.click();
		  
		  if(wb.getCurrentUrl().equalsIgnoreCase("http://demo.guru99.com/test/newtours/register.php"))
		  {   
			  System.out.println("Test Passed For Register Link on Home Page");
			  wb.navigate().back();
			  
		  }
		  else if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours")||working==("This section of our web site is currently under construction."))
		  {
			  System.out.println("Test Passed For Register Link on Home Page");
			  WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
		  }
		  else
		  {
			  System.out.println("Test Failed For Register Link on Home Page");
		  }
		  
		  
		  Thread.sleep(5000);
		  WebElement buisnessAbout = wb.findElement(By.linkText("Business Travel @ About.com"));
		  buisnessAbout.click();
		  
		  if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours") || working==("This section of our web site is currently under construction."))
		  {   
			  System.out.println("Test Passed For Buisness About Link on Home Page");
			  WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
			  			  
		  }
		  else
		  {
			  System.out.println("Test Failed For Buisness About Link on Home Page");
			  wb.navigate().to("http://demo.guru99.com/test/newtours/index.php");
		  }
		  
		   
	  }
	
	public static void FlightPage(WebDriver wb,String working)
	  {    
		  WebElement flights = wb.findElement(By.linkText("Flights"));
		  flights.click();
				  
		if(wb.getCurrentUrl().equalsIgnoreCase("http://demo.guru99.com/test/newtours/reservation.php"))
		  {    
			  System.out.println("Test Passed For Flight Link");
		  }
		 else if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours")|| working==("This section of our web site is currently under construction."))
		  {
			  System.out.println("Test Passed For Flight Link");
			  WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
		  }
		  else
		  {
			  System.out.println("Test Failed For Flight Link");
		  }
	  }
		
	public static void HotelPage(WebDriver wb,String working)
	  {    
		  WebElement hotel = wb.findElement(By.linkText("Hotels"));
		  hotel.click();
		 	 
		if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours") || working==("This section of our web site is currently under construction."))
		      {  
				 System.out.println("Test Passed For Hotel Link");
				 WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
				  back.click();
			   }
			  
		  else
		  {
			  System.out.println("Test Failed For Hotel Link");
		  }
	  }
	
	public static void CarRentalPage( WebDriver wb,String working)
	  {    
		   WebElement car_rentals = wb.findElement(By.linkText("Car Rentals"));
		   car_rentals.click();
		
		   if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours") || working==("This section of our web site is currently under construction."))
		     {
				System.out.println("Test Passed For Car Rental Link");	
				WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
				  back.click();
			 }
		  
		  else
		  {
			  System.out.println("Test Failed For Car Rental Link");
		  }
	  }
		
	
	public static void CruisesPage(WebDriver wb,String working)
	  {    
		  WebElement cruises = wb.findElement(By.linkText("Cruises"));
		  cruises.click();
		  
		  if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours") || working==("This section of our web site is currently under construction."))
		  {  
		     
			System.out.println("Test Passed For Cruises Link");
			WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
			  
		  }
		  else
		  {
			  System.out.println("Test Failed For Cruises Link");
		  }
	  }
		
		
	public static void DestinationsPage(WebDriver wb,String working)
	  {    
		  WebElement desti = wb.findElement(By.linkText("Destinations"));
		  desti.click();
			 
		  if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours") || working==("This section of our web site is currently under construction."))
		  {   
			System.out.println("Test Passed For Destinations Link");
			WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
			  
		  }
		  else
		  {
			  System.out.println("Test Failed For Destinations Link");
		  }
	  }	
		
		
	public static void VacationPage(WebDriver wb,String working)
	  {    
		  WebElement vacation = wb.findElement(By.linkText("Vacations"));
		  vacation.click();
		
		  if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours") || working==("This section of our web site is currently under construction."))
		  {   
			System.out.println("Test Passed For vacation Link");
			WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
			  
		  }
		  else
		  {
			  System.out.println("Test Failed For vacation Link");
		  }
	  }		
		
	public static void RegisterPage(WebDriver wb,String working)
	  {    
		  WebElement reg = wb.findElement(By.linkText("REGISTER"));
		  reg.click();
		  
		if(wb.getCurrentUrl().equalsIgnoreCase("http://demo.guru99.com/test/newtours/register.php"))
		  {   
			  System.out.println("Test Passed For Register Link");
		  }
		 else if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours")|| working==("This section of our web site is currently under construction."))
		  {
			  System.out.println("Test Passed For Register Link on Home Page");
			  WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
		  }
		  else
		  {
			  System.out.println("Test Failed For Register Link");
		  }
	  } 
	
	public static void SupportPage(WebDriver wb,String working)
	  {    
		  WebElement support = wb.findElement(By.linkText("SUPPORT"));
		  support.click();
		  
		if(wb.getCurrentUrl().equalsIgnoreCase("http://demo.guru99.com/test/newtours/support.php"))
		  {   
			  System.out.println("Test Passed For Support Link");
		  }
		 else if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours")|| working==("This section of our web site is currently under construction."))
		  {
			  System.out.println("Test Passed For Support Link on Home Page");
			  WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
		  }
		  else
		  {
			  System.out.println("Test Failed For Support Link");
		  }
	  } 
	
	public static void ContactPage(WebDriver wb,String working)
	  {    
		  WebElement contact = wb.findElement(By.linkText("CONTACT"));
		  contact.click();
		  
		  if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours") || working==("This section of our web site is currently under construction."))
		  {   
			  System.out.println("Test Passed For Contact Link");
			  WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
		  }
		  
		  else
		  {
			  System.out.println("Test Failed For Contact Link");
		  }
	  } 
	  
	
	public static void SignOnPage(WebDriver wb,String working)
	  {    
		  WebElement contact = wb.findElement(By.linkText("SIGN-ON"));
		  contact.click();
		  
		 if(wb.getCurrentUrl().equalsIgnoreCase("http://demo.guru99.com/test/newtours/login.php"))
		 {
			 System.out.println("Test Passed For SignOn Link");
		 }
		  
		  else if(wb.getTitle().equalsIgnoreCase("Under Construction: Mercury Tours") || working==("This section of our web site is currently under construction."))
		  {   
			  System.out.println("Test Passed For SignOn Link");
			  WebElement back = wb.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
			  back.click();
		  }
		  
		  else
		  {
			  System.out.println("Test Failed For Contact Link");
		  }
	  } 
	
	
	
	
	
	
	
	@Test(priority=1)
	  public void underConstruction() throws InterruptedException
	  {    
		  wb.get("http://demo.guru99.com/test/newtours/support.php");
		  WebElement mgs = wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]"));
		  String working = mgs.getText();
	  } 	
	
	
	
  @Test(priority=2)
  public void link() throws InterruptedException
  {    
	  LinkModule.HomePage(wb,working);
	  LinkModule.FlightPage(wb,working);
	  LinkModule.HotelPage(wb, working);
	  LinkModule.CarRentalPage(wb,working);
	  LinkModule.CruisesPage(wb,working);
	  LinkModule.DestinationsPage(wb,working);
	  LinkModule.VacationPage(wb,working);
	  LinkModule.RegisterPage(wb,working);
	  LinkModule.SupportPage(wb,working);
	  LinkModule.ContactPage(wb,working);
	  LinkModule.SignOnPage(wb, working);
  } 
  @BeforeTest
  public void beforeTest() throws InterruptedException
  {
	  System.setProperty("webdriver.chrome.driver","F:\\Drivers\\chromedriver_win32\\chromedriver.exe" );
	  wb = new ChromeDriver();
	  wb.get("http://demo.guru99.com/test/newtours/index.php");
	  wb.manage().window().maximize();
	  
	
	 
  }

  @AfterTest
  public void afterTest() 
  {
	  wb.close();
  }

}
