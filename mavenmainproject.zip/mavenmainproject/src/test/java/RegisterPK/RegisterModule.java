package RegisterPK;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;

public class RegisterModule
{
	    WebDriver wb;
					
  
	@Test    
	public void register() throws IOException
	  { 	  
			FileInputStream file1 = new FileInputStream("C:\\Users\\AISHAWARYA\\eclipse-workspace\\mavenmainproject\\ProjectExcelSheet.xlsx");
			XSSFWorkbook book1 = new XSSFWorkbook(file1);
		    XSSFSheet sh = book1.getSheet("registervalid");
		    XSSFSheet sh1 = book1.getSheet("registerInvalid");
		    for(int i=1;i<=sh.getLastRowNum(); i++)
		  	  { 
	    	      wb.findElement(By.linkText("REGISTER")).click();
    	   
		    	   String fname=sh.getRow(i).getCell(0).toString();
				  	String lname=sh.getRow(i).getCell(1).toString();
				   	String phno= sh.getRow(i).getCell(2).toString();
				  	String email=sh.getRow(i).getCell(3).toString();
				  	String addr=sh.getRow(i).getCell(4).toString();
				  	String city=sh.getRow(i).getCell(5).toString();
				  	String state=sh.getRow(i).getCell(6).toString();
				  	String postalcode= sh.getRow(i).getCell(7).toString();
				  	String country=sh.getRow(i).getCell(8).toString();
				  	String un=sh.getRow(i).getCell(9).toString();
				  	String pass=sh.getRow(i).getCell(10).toString();
				  	String cpass=sh.getRow(i).getCell(11).toString();
					   
				  	WebElement first_name=	wb.findElement(By.name("firstName"));
					first_name.sendKeys(fname);
					WebElement last_name=	wb.findElement(By.name("lastName"));
					last_name.sendKeys(lname);
					WebElement Phone_no=	wb.findElement(By.name("phone"));
					Phone_no.sendKeys(phno);
					WebElement Email=	wb.findElement(By.id("userName"));
					Email.sendKeys(email);
				
					WebElement Addr=wb.findElement(By.name("address1"));
					Addr.sendKeys(addr);
					WebElement City=	wb.findElement(By.name("city"));
					City.sendKeys(city);
					WebElement State=wb.findElement(By.name("state"));
					State.sendKeys(state);
					WebElement PostalCode=	wb.findElement(By.name("postalCode"));
					PostalCode.sendKeys(postalcode);
					Select c = new Select(wb.findElement(By.name("country")));
					c.selectByVisibleText(country);
				 
					WebElement UN=wb.findElement(By.id("email"));
					UN.sendKeys(un);
					WebElement Pass=wb.findElement(By.name("password"));
					Pass.sendKeys(pass);
					WebElement CPass=wb.findElement(By.name("confirmPassword"));
					CPass.sendKeys(cpass);
					WebElement Submit_btn=wb.findElement(By.name("submit"));
					Submit_btn.click();
				
	 System.out.println(fname+"  "+ lname+"  "+ phno+"  "+ email+"  "+ addr+"  "+ city+"  "+ state+"  "+ postalcode+"  "+ country+"  "+ un+"  "+ pass+"  "+ cpass);	
	
	 if(wb.getCurrentUrl().equalsIgnoreCase("http://demo.guru99.com/test/newtours/register_sucess.php")) 
	   {
		 System.out.println("Test Case Passed");	
				    
	   }
	 else
	 {
		 System.out.println("Test Case Failed");	
	 }
	}
		    
		    for(int i=1;i<=sh1.getLastRowNum(); i++)
		  	  { 
	    	      wb.findElement(By.linkText("REGISTER")).click();
  	   
		    	   String fname=sh1.getRow(i).getCell(0).toString();
				  	String lname=sh1.getRow(i).getCell(1).toString();
				   	String phno= sh1.getRow(i).getCell(2).toString();
				  	String email=sh1.getRow(i).getCell(3).toString();
				  	String addr=sh1.getRow(i).getCell(4).toString();
				  	String city=sh1.getRow(i).getCell(5).toString();
				  	String state=sh1.getRow(i).getCell(6).toString();
				  	String postalcode= sh1.getRow(i).getCell(7).toString();
				  	String country=sh1.getRow(i).getCell(8).toString();
				  	String un=sh1.getRow(i).getCell(9).toString();
				  	String pass=sh1.getRow(i).getCell(10).toString();
				  	String cpass=sh1.getRow(i).getCell(11).toString();
					   
				  	WebElement first_name=	wb.findElement(By.name("firstName"));
					first_name.sendKeys(fname);
					WebElement last_name=	wb.findElement(By.name("lastName"));
					last_name.sendKeys(lname);
					WebElement Phone_no=	wb.findElement(By.name("phone"));
					Phone_no.sendKeys(phno);
					WebElement Email=	wb.findElement(By.id("userName"));
					Email.sendKeys(email);
				
					WebElement Addr=wb.findElement(By.name("address1"));
					Addr.sendKeys(addr);
					WebElement City=	wb.findElement(By.name("city"));
					City.sendKeys(city);
					WebElement State=wb.findElement(By.name("state"));
					State.sendKeys(state);
					WebElement PostalCode=	wb.findElement(By.name("postalCode"));
					PostalCode.sendKeys(postalcode);
					Select c = new Select(wb.findElement(By.name("country")));
					c.selectByVisibleText(country);
				 
					WebElement UN=wb.findElement(By.id("email"));
					UN.sendKeys(un);
					WebElement Pass=wb.findElement(By.name("password"));
					Pass.sendKeys(pass);
					WebElement CPass=wb.findElement(By.name("confirmPassword"));
					CPass.sendKeys(cpass);
					WebElement Submit_btn=wb.findElement(By.name("submit"));
					Submit_btn.click();
					 System.out.println(fname+"  "+ lname+"  "+ phno+"  "+ email+"  "+ addr+"  "+ city+"  "+ state+"  "+ postalcode+"  "+ country+"  "+ un+"  "+ pass+"  "+ cpass);	
										
	if(wb.getCurrentUrl().equalsIgnoreCase("http://demo.guru99.com/test/newtours/register_sucess.php"))
		{
		System.out.println("Test Case Failed for invalid data");
		}
	else 
	{
		System.out.println("Test Case Passed for invalid data");
	}
		  	
		}  
	  }
	
	
	
	@BeforeTest
	public void setting()
	{
		System.setProperty("webdriver.chrome.driver", "F:\\Drivers\\chromedriver_win32\\chromedriver.exe");
		wb = new ChromeDriver();
		wb.get("http://demo.guru99.com/test/newtours");
		wb.manage().window().maximize();
		  
	}
	
	@AfterTest
	    public void afterregister()
	    { 
		  
	       wb.close();
	    }  
}
